$(document).ready(function(){
// use jQuery correctly with strict
    (function($) {
        "use strict";
        // your code
        
        /* ----------------------------------------
        Google Map - Info Window Style
        ---------------------------------------- */
        $('.gm-style-iw').parent().addClass('google_map_info_contents');
        
    })(jQuery);
});