<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from premiumlayers.net/demo/html/realtor/04-About-Us.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 09 Jul 2018 06:21:45 GMT -->
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Arya Real Estate | About Us</title>
<meta name="keywords" content="HTML5,CSS3,HTML,Template,Multi-Purpose,M_Adnan,Corporate Theme,Realtor | Real Estate HTML5 Templates" >
<meta name="description" content="Realtor | Real Estate HTML5 Template">
<meta name="author" content="M_Adnan">

<!-- FONTS ONLINE -->
<link href='http://fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Lato:100,300,400,700,900' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>

<!--MAIN STYLE-->
<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="css/main.css" rel="stylesheet" type="text/css">
<link href="css/style.css" rel="stylesheet" type="text/css">
<link href="css/animate.css" rel="stylesheet" type="text/css">
<link href="css/responsive.css" rel="stylesheet" type="text/css">
<link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">

<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->

</head>
<script>
function myFunction() {
    document.getElementById("about").classList.add('active');
    document.getElementById("services").classList.remove('active');
    document.getElementById("home").classList.remove('active');
    document.getElementById("contact").classList.remove('active');   
}
</script>
<body onload="myFunction()" >
<!-- Page Wrap ===========================================-->
<div id="wrap"> 
  
  <!--======= HEADER =========-->
  <?php
        include 'header.php';

    ?>
  
  <!--======= BANNER =========-->
  <div class="sub-banner">
    <div class="overlay">
      <div class="container">
        <h1>ABOUT US</h1>
        <ol class="breadcrumb">
          <li class="pull-left">ABOUT us</li>
          <li><a href="#">Home</a></li>
          <li class="active">ABOUT Us</li>
        </ol>
      </div>
    </div>
  </div>
  
  
  <!--======= WHAT WE DO =========-->
  <section class="what-we-do">
    <div class="container"> 
      
      <!--======= TITTLE =========-->
      <div class="tittle"> <img src="images/head-top.png" alt="">
        <h3>who we are</h3>
        <p>We are real estate service agent , construction service provider other than residential complex, including commercial/industrial buildings or civil structures. <br/>Arya Real Estate is incorporated in 2016, to undertake construction & contracting business. <br/>Arya Real Estate was founded by Shri  K.C. Pan, a first generation entrepreneur, a civil engineer by qualification and a visionary. With over 10 years of experience in educational institute and restaurant business, K.C. Pan, as Chairman & Managing Director of Arya Real Estate ., has been at the forefront of the real estate industry, following its motto “Turning Dreams into Reality” through building world class residential and commercial projects. <br/>In the span of a few years, Arya Real Estate . has become one of the fastest growing construction companies of  INDIA and is now amongst the largest public-listed real estate development companies in INDIA. <br/>The company is currently working on 10 real estate projects – 5 Integrated Townships including a Hi-Tech Township, 3 Group Housing projects, 1 Shopping Malls & Commercial Complexes, and 1 Hotel projects. Besides, Arya Real Estate . has a diversified portfolio of infrastructure and construction contracting businesses. <br/>To undertake such expansion, Arya Real Estate . today, is backed by a professional and competent Team Arya: a constantly growing workforce of currently over one hundred professionals, including highly-qualified engineers, architects, Chartered Accountants, MBA’s, etc. With high standards in line with Arya vision and ambitions, Team Arya makes Arya Real Estate . a strong, structured and high-growth company with a bright future. Taking forward our vision to provide an environment of professionalism, competence, teamwork and service excellence, Arya Real Estate . is working towards benchmarking our HR policies with the best employers and international standards. <br/>Arya Real Estate’ uniqueness also lies in the fact that the company doesn’t give its projects on sub contract: while assuring timely completion, this also allows keeping pace with the progress in construction technology, helping to give clients “value for money”. <br/>For  Arya Real Estate, environment protection, innovative architecture and customer satisfaction are the standards of today and tomorrow’s in real estate development.
</p>
      </div>
      <div role="tabpanel"> 
        
        <!--======= NAV TABS =========-->
        <ul class="nav nav-tabs" role="tablist">
          <li role="presentation" class="active"><a href="#what-we" aria-controls="home" role="tab" data-toggle="tab"><i class="fa fa-bullhorn"></i> <span class="font-montserrat">what we do</span></a></li>
          <li role="presentation"><a href="#mission" aria-controls="profile" role="tab" data-toggle="tab"><i class="fa fa-rocket"></i><span class="font-montserrat">our mission</span></a></li>
          <li role="presentation"><a href="#vision" aria-controls="messages" role="tab" data-toggle="tab"><i class="fa fa-lightbulb-o"></i><span class="font-montserrat">our vision</span></a></li>
        </ul>
        
        <!--======= TAB CONTENT =========-->
        <div class="tab-content">
        
        <!--======= WHAT WE DO =========-->
          <div role="tabpanel" class="tab-pane animated-6s flipInX active" id="what-we">
            <h4>make your family happy</h4>
            <p>Real estate agent service</p>
            <p>Construction services other then residential complex, including commercial/industrial buildings or civil structures</p>
            <p>Land purchase, sale & Renting</p>
            <p>Financial Support</p>
            <p>Land purchase, sale & Renting</p>
          </div>
          
          <!--======= OUR MISSION =========-->
          <div role="tabpanel" class="tab-pane animated-6s flipInX" id="mission">
            <h4>make everybody happy</h4>
            <p>The mate was a mighty sailin' man the Skipper brave and sure. Five passengers set sail that day for a three hour tour a three hour tour. The first mate and his Skipper too will do their very best to make the others comfortable in their tropic island nest. If you have a problem if no one else can help and if you can find </p>
          </div>
          
          <!--======= OUR VISION =========-->
          <div role="tabpanel" class="tab-pane animated-6s flipInX" id="vision">
            <h4>make your family happy</h4>
            <p>Construction services other then residential complex, including commercial/industrial buildings or civil structures</p>
            <p>Land purchase, sale & Renting </p>
          </div>
        </div>
      </div>
    </div>
  </section>
  
  <!--======= TEAM =========-->
  <section id="team">
    <div class="container"> 
      
      <!--======= TITTLE =========-->
      <div class="tittle"> <img src="images/head-top.png" alt="">
        <h3>our great team</h3>
        <p>Teamwork is so important that it is virtually impossible for you to reach the heights of your capabilities or make the money that you want without becoming very good at it</p>
      </div>
      <div class="row">
        <div class="col-md-6"> 
          
          <!--======= TEAM ROW =========-->
          <ul class="row">
            
            <!--======= TEAM =========-->
            <li class="col-sm-6">
              <div class="team"> <img class="img-responsive" src="images/agent-1.jpg" alt="">
                <div class="team-over"> 
                  <!--======= SOCIAL ICON =========-->
                  <ul class="social_icons animated-6s fadeInUp">
                    <li class="facebook"><a href="#."><i class="fa fa-facebook"></i></a></li>
                    <li class="twitter"><a href="#."><i class="fa fa-twitter"></i></a></li>
                    <li class="googleplus"><a href="#."><i class="fa fa-google-plus"></i></a></li>
                    <li class="linkedin"><a href="#."><i class="fa fa-linkedin"></i></a></li>
                  </ul>
                </div>
                
                <!--======= TEAM DETAILS =========-->
                <div class="team-detail">
                  <h6>KHAGESHVAR PAN</h6>
                  <p>Founder</p>
                </div>
              </div>
            </li>
            
            <!--======= TEAM =========-->
            <li class="col-sm-6">
              <div class="team"> <img class="img-responsive" src="images/agent-2.jpg" alt="">
                <div class="team-over"> 
                  <!--======= SOCIAL ICON =========-->
                  <ul class="social_icons animated-6s fadeInUp">
                    <li class="facebook"><a href="#."><i class="fa fa-facebook"></i></a></li>
                    <li class="twitter"><a href="#."><i class="fa fa-twitter"></i></a></li>
                    <li class="googleplus"><a href="#."><i class="fa fa-google-plus"></i></a></li>
                    <li class="linkedin"><a href="#."><i class="fa fa-linkedin"></i></a></li>
                  </ul>
                </div>
                
                <!--======= TEAM DETAILS =========-->
                <div class="team-detail">
                  <h6>Hendrick jack </h6>
                  <p>co-Founder</p>
                </div>
              </div>
            </li>
          </ul>
        </div>
        <div class="col-md-6"> 
          
          <!--======= TEAM ROW =========-->
          <ul class="row">
            
            <!--======= TEAM =========-->
            <li class="col-sm-6">
              <div class="team"> <img class="img-responsive" src="images/agent-3.jpg" alt="">
                <div class="team-over"> 
                  <!--======= SOCIAL ICON =========-->
                  <ul class="social_icons animated-6s fadeInUp">
                    <li class="facebook"><a href="#."><i class="fa fa-facebook"></i></a></li>
                    <li class="twitter"><a href="#."><i class="fa fa-twitter"></i></a></li>
                    <li class="googleplus"><a href="#."><i class="fa fa-google-plus"></i></a></li>
                    <li class="linkedin"><a href="#."><i class="fa fa-linkedin"></i></a></li>
                  </ul>
                </div>
                
                <!--======= TEAM DETAILS =========-->
                <div class="team-detail">
                  <h6>charles edward </h6>
                  <p>team leader </p>
                </div>
              </div>
            </li>
            
            <!--======= TEAM =========-->
            <li class="col-sm-6">
              <div class="team"> <img class="img-responsive" src="images/agent-4.jpg" alt="">
                <div class="team-over"> 
                  <!--======= SOCIAL ICON =========-->
                  <ul class="social_icons animated-6s fadeInUp">
                    <li class="facebook"><a href="#."><i class="fa fa-facebook"></i></a></li>
                    <li class="twitter"><a href="#."><i class="fa fa-twitter"></i></a></li>
                    <li class="googleplus"><a href="#."><i class="fa fa-google-plus"></i></a></li>
                    <li class="linkedin"><a href="#."><i class="fa fa-linkedin"></i></a></li>
                  </ul>
                </div>
                
                <!--======= TEAM DETAILS =========-->
                <div class="team-detail">
                  <h6>jessica wevins </h6>
                  <p>team leader</p>
                </div>
              </div>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </section>
  
  <!--======= CALL US =========-->
  
  <section class="call-us">
    <div class="overlay">
      <div class="container">
        <ul class="row">
          <li class="col-sm-6">
            <h4>Do you want to sell, purchase, rent your property ?</h4>
            <h6>Just Call us</h6>
          </li>
          <li class="col-sm-4">
            <h1>+91 7667757440</h1>
          </li>
          <li class="col-sm-2 no-padding"> <a href="contact.php" class="btn">contact us</a> </li>
        </ul>
      </div>
    </div>
  </section>
  
  <!--======= PARTHNER =========-->
  <section class="parthner">
    <div class="container"> 
      <!--======= TITTLE =========-->
      <div class="tittle"> <img src="images/head-top.png" alt="">
        <h3>our trusted partners</h3>
        <!--<p></p>-->
      </div>
      
      <!--======= PARTHNERS =========-->
      <div class="parthner-slide">
        <div class="part"> <a href="#."> <img src="images/parthner-img-1.png" alt="" > </a> </div>
        
        <!--======= PARTHNERS =========-->
        <div class="part"> <a href="#."> <img src="images/parthner-img-2.png" alt="" > </a> </div>
        
        <!--======= PARTHNERS =========-->
        <div class="part"> <a href="#."> <img src="images/parthner-img-3.png" alt="" > </a> </div>
        
        <!--======= PARTHNERS =========-->
        <div class="part"> <a href="#."> <img src="images/parthner-img-4.png" alt="" > </a> </div>
        
        <!--======= PARTHNERS =========-->
        <div class="part"> <a href="#."> <img src="images/parthner-img-5.png" alt="" > </a> </div>
        
        <!--======= PARTHNERS =========-->
        <div class="part"> <a href="#."> <img src="images/parthner-img-3.png" alt="" > </a> </div>
        
        <!--======= PARTHNERS =========-->
        <div class="part"> <a href="#."> <img src="images/parthner-img-4.png" alt="" > </a> </div>
        
        <!--======= PARTHNERS =========-->
        <div class="part"> <a href="#."> <img src="images/parthner-img-5.png" alt="" > </a> </div>
        
        <!--======= PARTHNERS =========-->
        <div class="part"> <a href="#."> <img src="images/parthner-img-3.png" alt="" > </a> </div>
        
        <!--======= PARTHNERS =========-->
        <div class="part"> <a href="#."> <img src="images/parthner-img-4.png" alt="" > </a> </div>
        
        <!--======= PARTHNERS =========-->
        <div class="part"> <a href="#."> <img src="images/parthner-img-5.png" alt="" > </a> </div>
        
        <!--======= PARTHNERS =========-->
        <div class="part"> <a href="#."> <img src="images/parthner-img-3.png" alt="" > </a> </div>
      </div>
    </div>
  </section>
  
  <!--======= FOOTER =========-->
  <?php include'footer.php'; ?>
</div>

</body>

</html>